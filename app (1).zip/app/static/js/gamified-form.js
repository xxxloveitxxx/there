// static/js/gamified-form.js

window.initGamifiedForm = function () {
    // If the key element (like btnNext) is not in the DOM, exit the function safely.
  if (!document.getElementById('btn-next')) {
      return; 
  }
  const missionCards = document.querySelectorAll('.mission-card');
  const btnPrev = document.getElementById('btn-prev');
  const btnNext = document.getElementById('btn-next');
  const progressFill = document.getElementById('progress-fill');
  const progressText = document.getElementById('progress-text');
  const achievement = document.getElementById('achievement-badge');
  const confettiWrap = document.getElementById('confetti-container');
  const formContainer = document.querySelector('.gf-container');

  let currentMission = 0;
  const totalMissions = missionCards.length;

  /* ==========================
     CORE DISPLAY HANDLER
  ========================== */
  function showMission(index) {
    missionCards.forEach((card, i) => {
      card.classList.toggle('active', i === index);
    });
  }

  /* ==========================
     PROGRESS BAR
  ========================== */
  function updateProgress() {
    const percentage = ((currentMission + 1) / totalMissions) * 100;
    progressFill.style.width = percentage + '%';
    progressText.textContent = `${currentMission + 1}/${totalMissions}`;
  }

  /* ==========================
     BUTTON STATES
  ========================== */
  function updateButtons() {
    btnPrev.style.visibility = currentMission === 0 ? 'hidden' : 'visible';

    if (currentMission === totalMissions - 1) {
      btnNext.textContent = '🚀 Launch Deal!';
      btnNext.className = btnNext.className.replace('btn-next', 'btn-submit');
    } else {
      btnNext.innerHTML = 'Next Mission <i class="fas fa-arrow-right"></i>';
      btnNext.className = btnNext.className.replace('btn-submit', 'btn-next');
    }
  }

  /* ==========================
     MISSION VALIDATION
  ========================== */
  function validateMission() {
    const inputs = missionCards[currentMission].querySelectorAll(
      'input[required], select[required], textarea[required], input[type="checkbox"][required]'
    );

    for (let input of inputs) {
      if (input.type === 'checkbox') {
        if (!input.checked) {
          input.focus();
          return false;
        }
      } else {
        if (!input.value.trim()) {
          input.focus();
          return false;
        }
      }
    }
    return true;
  }

  /* ==========================
     CONFETTI + ACHIEVEMENTS
  ========================== */
  function showBadge(message = 'Mission Complete! 🎉') {
    achievement.textContent = message;
    achievement.classList.add('show');
    createConfetti();
  }

  function hideBadge() {
    achievement.classList.remove('show');
  }

  function createConfetti() {
    confettiWrap.innerHTML = '';

    const colors = ['#64ffda', '#f72585', '#ff9e00', '#4361ee', '#7209b7'];

    for (let i = 0; i < 80; i++) {
      const piece = document.createElement('div');
      const size = Math.random() * 6 + 4;
      const color = colors[Math.floor(Math.random() * colors.length)];
      const rotation = Math.random() * 360;

      piece.className = 'confetti';
      piece.style.cssText = `
        position:absolute;
        left:${Math.random() * 100}%;
        top:${Math.random() * 100}%;
        width:${size}px;
        height:${size}px;
        background:${color};
        transform:rotate(${rotation}deg);
        animation:confettiFall ${Math.random() * 2 + 1}s forwards;
      `;

      if (Math.random() < 0.5) piece.style.borderRadius = '50%';

      confettiWrap.appendChild(piece);
    }
  }

  /* Inject confetti keyframes once */
  if (!document.getElementById('confettiKeyframes')) {
    const style = document.createElement('style');
    style.id = 'confettiKeyframes';
    style.textContent = `
      @keyframes confettiFall {
        0% { transform: translateY(-80px) rotate(0deg); opacity: 1; }
        100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
      }
    `;
    document.head.appendChild(style);
  }

  /* ==========================
     NAVIGATION HANDLERS
  ========================== */
  btnNext.addEventListener('click', () => {
    if (currentMission < totalMissions - 1) {
      if (!validateMission()) {
        alert('Please complete all required fields.');
        return;
      }

      showBadge();

      setTimeout(() => {
        hideBadge();
        currentMission++;
        showMission(currentMission);
        updateProgress();
        updateButtons();

        if (formContainer) {
          formContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } else {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      }, 700);
    } else {
      if (!validateMission()) return alert('Please complete all required fields.');

      showBadge('Deal Complete! 🚀');
      setTimeout(() => {
        document.getElementById('new-txn-form').submit();
      }, 1000);
    }
  });

  btnPrev.addEventListener('click', () => {
    if (currentMission > 0) {
      currentMission--;
      showMission(currentMission);
      updateProgress();
      updateButtons();

      if (formContainer) {
        formContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  });

  /* ==========================
     INITIALIZE STATE
  ========================== */
  showMission(currentMission);
  updateProgress();
  updateButtons();
};

/* Auto-init on page load */
document.addEventListener('DOMContentLoaded', window.initGamifiedForm);
